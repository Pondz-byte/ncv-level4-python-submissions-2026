COMMUNITY WATER BILLING SYSTEM - SUBMISSION NOTES

Files:
- water_billing.py: Python solution.
- water_readings.txt: the supplied 220-record dataset.
- billing_report.txt: generated billing report.
- errors.log: generated rejection log.

How to run in Thonny:
1. Keep all three input/output files in the same folder as water_billing.py.
2. Open water_billing.py in Thonny.
3. Press F5 (Run).
4. Open billing_report.txt and errors.log to inspect the results.

Tariff boundary checks:
- 6 kL  = R0.00
- 7 kL  = R8.50
- 20 kL = R119.00
- 21 kL = R131.00
- 25 kL = R179.00

The supplied file has 220 records. The program validates each line and
generates the report and error log. Capture your own screenshots in Thonny
showing the successful run and the contents of both output files; screenshots
are not fabricated or included in this ZIP.
