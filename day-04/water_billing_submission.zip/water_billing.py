# ============================================================
# COMMUNITY WATER CONSUMPTION AND BILLING MANAGEMENT SYSTEM
# Python practical assignment - Thonny
# ============================================================

# ------------------------------
# 1. CONSTANTS
# ------------------------------
INPUT_FILE = "water_readings.txt"
REPORT_FILE = "billing_report.txt"
ERROR_FILE = "errors.log"

FREE_LIMIT = 6
SECOND_LIMIT = 20
SECOND_RATE = 8.50
THIRD_RATE = 12.00


# ------------------------------
# 2. READ INPUT FILE
# ------------------------------
def read_file(filename):
    """Read all lines from the supplied water readings file."""
    try:
        file = open(filename, "r", encoding="utf-8")
        lines = file.readlines()
        file.close()
        return lines
    except FileNotFoundError:
        print("ERROR: The file", filename, "was not found.")
        print("Place the text file in the same folder as this Python program.")
        return None


# ------------------------------
# 3. VALIDATE AND STORE RECORDS
# ------------------------------
def validate_records(lines):
    """Validate records and store accepted households in a dictionary."""
    households = {}
    errors = []
    rejected_count = 0
    line_number = 0

    for line in lines:
        line_number = line_number + 1
        clean_line = line.strip()

        if clean_line == "":
            errors.append("Line " + str(line_number) + ": Empty record.")
            rejected_count = rejected_count + 1
            continue

        fields = clean_line.split(",")

        if len(fields) != 5:
            errors.append(
                "Line " + str(line_number) + ": Expected 5 fields but found "
                + str(len(fields)) + ". Record: " + clean_line
            )
            rejected_count = rejected_count + 1
            continue

        meter = fields[0].strip()
        name = fields[1].strip()
        previous_text = fields[2].strip()
        current_text = fields[3].strip()
        area = fields[4].strip()

        # Check required text fields.
        if meter == "" or name == "" or area == "":
            errors.append(
                "Line " + str(line_number)
                + ": Missing meter number, household name or area. Record: "
                + clean_line
            )
            rejected_count = rejected_count + 1
            continue

        # Check for duplicate meter numbers.
        if meter in households:
            errors.append(
                "Line " + str(line_number) + ": Duplicate meter number "
                + meter + ". Record: " + clean_line
            )
            rejected_count = rejected_count + 1
            continue

        # Check that both readings contain numeric values.
        try:
            previous = int(previous_text)
            current = int(current_text)
        except ValueError:
            errors.append(
                "Line " + str(line_number)
                + ": Previous/current reading is not a whole number. Record: "
                + clean_line
            )
            rejected_count = rejected_count + 1
            continue

        # Readings cannot be negative.
        if previous < 0 or current < 0:
            errors.append(
                "Line " + str(line_number)
                + ": Negative meter reading. Record: " + clean_line
            )
            rejected_count = rejected_count + 1
            continue

        # Current reading cannot be lower than previous reading.
        if current < previous:
            errors.append(
                "Line " + str(line_number)
                + ": Current reading is below previous reading. Record: "
                + clean_line
            )
            rejected_count = rejected_count + 1
            continue

        # Store each accepted household using its meter number as the key.
        households[meter] = {
            "name": name,
            "previous": previous,
            "current": current,
            "area": area
        }

    return households, errors, rejected_count


# ------------------------------
# 4. CALCULATE CONSUMPTION
# ------------------------------
def calculate_consumption(household):
    """Return monthly water consumption in kilolitres."""
    usage = household["current"] - household["previous"]
    return usage


# ------------------------------
# 5. CALCULATE PROGRESSIVE BILL
# ------------------------------
def calculate_bill(usage):
    """Calculate the bill using the three progressive tariff bands."""
    bill = 0.0

    # First 6 kL are free.
    if usage <= FREE_LIMIT:
        bill = 0.0

    # Above 6 kL and up to 20 kL is charged at R8.50 per kL.
    elif usage <= SECOND_LIMIT:
        bill = (usage - FREE_LIMIT) * SECOND_RATE

    # Above 20 kL: charge the first 14 chargeable kL at R8.50,
    # then charge each additional kL at R12.00.
    else:
        bill = (SECOND_LIMIT - FREE_LIMIT) * SECOND_RATE
        bill = bill + ((usage - SECOND_LIMIT) * THIRD_RATE)

    return bill


# ------------------------------
# 6. CLASSIFY CONSUMPTION
# ------------------------------
def classify_consumption(usage):
    """Return LOW, MODERATE or HIGH."""
    if usage <= 20:
        category = "LOW"
    elif usage <= 50:
        category = "MODERATE"
    else:
        category = "HIGH"

    return category


# ------------------------------
# 7. MANUALLY RANK TOP FIVE
# ------------------------------
def find_top_five(households):
    """Find the five highest consumers without sorted(), max() or min()."""
    top_five = []
    already_selected = []

    # Repeat up to five times to select the next highest consumer.
    for rank in range(5):
        highest_meter = ""
        highest_usage = -1

        # Search through every accepted household.
        for meter in households:
            if meter not in already_selected:
                usage = households[meter]["usage"]

                if usage > highest_usage:
                    highest_usage = usage
                    highest_meter = meter

        if highest_meter != "":
            top_five.append((highest_meter, highest_usage))
            already_selected.append(highest_meter)

    return top_five


# ------------------------------
# 8. CREATE BILLING REPORT
# ------------------------------
def write_billing_report(households, top_five, rejected_count):
    """Write household billing details, top five and summary."""
    report = open(REPORT_FILE, "w", encoding="utf-8")

    report.write("COMMUNITY WATER CONSUMPTION AND BILLING REPORT\n")
    report.write("=" * 78 + "\n")
    report.write(
        f"{'Meter':<8}{'Household':<22}{'Area':<17}"
        f"{'Usage (kL)':>12}{'Category':>12}{'Bill (R)':>12}\n"
    )
    report.write("-" * 78 + "\n")

    accepted_count = 0
    total_usage = 0
    total_billing = 0.0
    low_count = 0
    moderate_count = 0
    high_count = 0

    for meter in households:
        item = households[meter]
        usage = item["usage"]
        bill = item["bill"]
        category = item["category"]

        report.write(
            f"{meter:<8}{item['name'][:21]:<22}{item['area'][:16]:<17}"
            f"{usage:>12}{category:>12}{bill:>12.2f}\n"
        )

        accepted_count = accepted_count + 1
        total_usage = total_usage + usage
        total_billing = total_billing + bill

        if category == "LOW":
            low_count = low_count + 1
        elif category == "MODERATE":
            moderate_count = moderate_count + 1
        else:
            high_count = high_count + 1

    report.write("\n" + "=" * 78 + "\n")
    report.write("TOP FIVE HIGHEST-CONSUMING HOUSEHOLDS\n")
    report.write("-" * 78 + "\n")

    rank = 0
    for entry in top_five:
        rank = rank + 1
        meter = entry[0]
        usage = entry[1]
        item = households[meter]
        report.write(
            str(rank) + ". " + meter + " - " + item["name"]
            + " (" + item["area"] + "): " + str(usage) + " kL\n"
        )

    report.write("\nSUMMARY\n")
    report.write("-" * 78 + "\n")
    report.write("Accepted records: " + str(accepted_count) + "\n")
    report.write("Rejected records: " + str(rejected_count) + "\n")
    report.write("Total consumption: " + str(total_usage) + " kL\n")
    report.write("Total amount billed: R" + format(total_billing, ".2f") + "\n")
    report.write("LOW households: " + str(low_count) + "\n")
    report.write("MODERATE households: " + str(moderate_count) + "\n")
    report.write("HIGH households: " + str(high_count) + "\n")

    report.close()


# ------------------------------
# 9. WRITE REJECTION LOG
# ------------------------------
def write_error_log(errors):
    """Write every rejected record and its reason to errors.log."""
    error_file = open(ERROR_FILE, "w", encoding="utf-8")

    error_file.write("WATER READINGS - REJECTED RECORDS\n")
    error_file.write("=" * 60 + "\n")

    if len(errors) == 0:
        error_file.write("No rejected records.\n")
    else:
        for error in errors:
            error_file.write(error + "\n")

    error_file.close()


# ------------------------------
# 10. MAIN PROGRAM
# ------------------------------
def main():
    lines = read_file(INPUT_FILE)

    # Stop if the input file could not be opened.
    if lines is None:
        return

    households, errors, rejected_count = validate_records(lines)

    # Calculate usage, bill and category for every accepted household.
    for meter in households:
        usage = calculate_consumption(households[meter])
        bill = calculate_bill(usage)
        category = classify_consumption(usage)

        households[meter]["usage"] = usage
        households[meter]["bill"] = bill
        households[meter]["category"] = category

    # Rank the five highest-consuming households manually.
    top_five = find_top_five(households)

    # Create the two required output files.
    write_billing_report(households, top_five, rejected_count)
    write_error_log(errors)

    print("WATER BILLING SYSTEM COMPLETED")
    print("--------------------------------")
    print("Total lines read:", len(lines))
    print("Accepted records:", len(households))
    print("Rejected records:", rejected_count)
    print("Billing report created:", REPORT_FILE)
    print("Error log created:", ERROR_FILE)


# Run the main program.
if __name__ == "__main__":
    main()
